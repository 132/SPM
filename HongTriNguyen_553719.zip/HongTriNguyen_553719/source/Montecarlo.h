#pragma once

namespace Montecarlo {

}
