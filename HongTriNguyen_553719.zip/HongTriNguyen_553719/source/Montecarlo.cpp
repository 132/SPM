#include "Montecarlo.h"

namespace Montecarlo {
}
